import datetime
import geocoder
import pyttsx3 as p
import speech_recognition as sr
import randfacts
import pywhatkit
from Selenium_web import *
from jokes import *
from tkinter import *
from PIL import ImageTk, Image

class GUI:
    def __init__(self):
        self.root = Tk()
        self.root.title('NOVA')
        self.root.geometry('600x600')

        # Background Image
        background_image = Image.open("Nova.jpg")
        self.photo = ImageTk.PhotoImage(background_image)

        self.panel = Label(self.root, image=self.photo)
        self.panel.pack(fill='both', expand=True)

        # User Text Frame
        userFrame = Frame(self.root, bg='#f0f0f0', bd=5)
        userFrame.place(relx=0.5, rely=0.8, relwidth=0.75, relheight=0.1, anchor='n')

        self.userText = StringVar()
        self.userText.set("It's Me NOVA: Your Voice Assistant")

        top = Label(userFrame, textvariable=self.userText, bg='#f0f0f0', fg='#e67813', font=('Georgia', 18))
        top.pack(fill='both', expand=True)

        # Buttons
        btnFrame = Frame(self.root, bg='#f0f0f0')
        btnFrame.place(relx=0.5, rely=0.9, relwidth=0.75, relheight=0.1, anchor='n')

        btn1 = Button(btnFrame, text='Speak', font=('Arial', 18), bg='#C0392B', fg='white', command=self.clicked)
        btn1.pack(side='left', fill='both', expand=True, padx=10, pady=10)

        btn2 = Button(btnFrame, text='Close', font=('Arial', 18), bg='#C0392B', fg='white', command=self.root.destroy)
        btn2.pack(side='right', fill='both', expand=True, padx=10, pady=10)

        self.voice_assistant_initialized = False
        self.r = sr.Recognizer()

        self.root.mainloop()

    def speak(self, text):
        rate = engine.getProperty('rate')
        engine.setProperty('rate', 190)
        voices = engine.getProperty('voices')
        engine.setProperty('voice', voices[1].id)
        engine.say(text)
        engine.runAndWait()

    def greet_user(self):
        self.speak("Hello, I am your voice Assistant. What can I do for you?")
        self.voice_assistant_initialized = True
        self.listen_and_respond()  # Call method to listen for user input and respond

    def listen_and_respond(self):
        try:
            with sr.Microphone() as source:
                self.userText.set("Listening...")
                audio = self.r.listen(source)
                text2 = self.r.recognize_google(audio)
                self.userText.set(text2)  # Display recognized text

            if "information" in text2:
                self.speak("What information do you need?")
                with sr.Microphone() as source:
                    audio = self.r.listen(source)
                    infor = self.r.recognize_google(audio)
                self.speak("Searching {} in Wikipedia".format(infor))
                assist = infow()
                assist.get_info(infor)
                # Perform Wikipedia search here

            elif "play" in text2 and "video" in text2:
                self.speak("You want me to play which video?")
                with sr.Microphone() as source:
                    audio = self.r.listen(source)
                    vid = self.r.recognize_google(audio)
                self.speak("Playing {} on YouTube".format(vid))
                pywhatkit.playonyt(vid)

            elif "fact" in text2 or "facts" in text2:
                self.speak("Sure")
                x = randfacts.get_fact()
                self.userText.set(x)
                self.speak("Did you know that, " + x)

            elif "joke" in text2 or "jokes" in text2:
                ar = joke()
                self.speak(ar[0])
                self.speak(ar[1])

            elif "date and time" in text2 or "current time" in text2:
                now = datetime.datetime.now()
                current_datetime = now.strftime("%Y-%m-%d %H:%M:%S")
                self.speak(f"The current date and time is {current_datetime}")

            elif "location" in text2 or "current location" in text2:
                g = geocoder.ip('me')
                COUNTRY_MAPPING = {
                    'IN': 'India',
                    # Add more mappings as needed for other countries
                }

                city = g.city
                state = g.state
                country_code = g.country  # Assuming 'country' field returns 'IN'
                country = COUNTRY_MAPPING.get(country_code, country_code)

                if city and state and country:
                    self.speak(f"You are currently in {city} city, {state} state and country {country}")
                else:
                    self.speak("Sorry, the location can't be determined")

            elif "your name" in text2 or "who are you" in text2:
                self.speak("My name is Nova")

            else:
                self.speak("I didn't understand that. Please try again.")

            self.listen_and_respond()  # Continue listening for further input

        except sr.UnknownValueError:
            self.speak("Sorry, I couldn't understand that. Please try again.")
            self.listen_and_respond()  # Continue listening for further input

    def clicked(self):
        if not self.voice_assistant_initialized:
            self.greet_user()
        else:
            self.listen_and_respond()  # Start listening and responding immediately if already initialized

# Initialize the pyttsx3 engine
engine = p.init()

# Initialize the GUI
gui = GUI()
