import time

from selenium import webdriver
from selenium.common import StaleElementReferenceException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class infow():
    def __init__(self):
        self. driver= webdriver.Chrome()

    def get_info(self,query):
        self.query=query

        self.driver.get(url="https://www.wikipedia.org")
        search=self.driver.find_element("xpath","//*[@id='searchInput']")
        search.click()
        search.send_keys(query)

        for i in range(3):  # Retry 3 times
            try:
                enter = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//*[@id='search-form']/fieldset/button"))
                )
                enter.click()
                time.sleep(300)  # Exit the loop if click is successful
            except StaleElementReferenceException:
                pass





